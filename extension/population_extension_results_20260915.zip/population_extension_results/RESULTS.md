# Preliminary SciPy reproduction: population extension

Model source: `extension/wnt_hox_ra_revised_population_dynamics.pdf` (September 2026).
All values below are recomputed from the 14 ODEs. No neural networks or parameter fitting.

## Main result to present

Under severe APC loss, a 48-hour ATRA input reduces cell abundance while increasing the
model's reduced HOX transcriptional index. These are different model outputs and can move
in opposite directions. After washout, stem-like cells start regrowing while still depleted.

| Output at 88 h | Control | ATRA | Change relative to control |
|---|---:|---:|---:|
| Total population / carrying capacity | 0.8500 | 0.8134 | -4.30% |
| Stem-like population / carrying capacity | 0.6188 | 0.4309 | -30.36% |
| ALDH-like fraction of all cells | 0.1271 | 0.1003 | -21.03% |
| Absolute ALDH-like population / carrying capacity | 0.1080 | 0.0816 | -24.43% |
| Reduced HOX index | 0.2863 | 0.4334 | +0.1472 index units |

The ALDH share **within the residual stem pool** rises from 17.46% to
18.94%, even though the absolute ALDH population and its fraction of all cells
both fall. The denominator matters.

HOXA5 increases 4.116-fold; HOXA13 falls to 0.677 times control;
CYP26A1 rises 1.389-fold. These are scaled model concentrations, not measured expression data.

The maintenance index is 0.3139 at exposure end (below the exact contraction threshold 0.5).
It re-crosses at 94.905 h from simulation baseline, or
6.905 h after washout. At that time the stem-like population remains
31.54% below matched control. At 168 h it remains
22.61% below control.

## What was completed

- Implemented all seven molecular, four HOX-program, and three population equations.
- Used the supplied parameters, separate untreated 720-h preconditioning for every parameter set,
  matched controls, BDF (rtol 1e-9, atol 1e-11, max step 0.5 h), and 0.125-h output spacing.
- Simulated all four disease regimes; a 5-by-5 dose-duration grid; equal-area schedules;
  selective HOX-arm blockades; three mechanism ablations; five Hill-shape settings.
- Ran 160 Latin hypercube samples of the ten specified couplings over [0.85,1.15]
  log-uniform multipliers, seed 20260915. 160/160 preserve lower ALDH-like
  fraction and higher HOX index. The crossing-time 5th/median/95th percentiles are
  94.450, 94.922, 95.504 h. These are parameter-perturbation intervals,
  not statistical confidence intervals or a Bayesian posterior.
- Reproduced numerical Figures 2–14 and 17 as 14 PNG/vector-PDF pairs. Figure 1 is a schematic;
  Figures 15–16 (multistability searches) and the identifiability analysis are not rerun here.
- Checked positivity, bounded programs/populations, exact population balance identities, and
  agreement with a tighter independent Radau integration. Maximum scaled state difference:
  1.91e-08.

## Reproduction choices and limits

**Not every printed number is reproduced.** Nominal, regime, duration and schedule
comparisons are audited in `tables/pdf_comparison.csv`. The no-differentiation
ALDH-fraction ratio is 1.0524
(PDF: 1.133). Removing RA-to-HOX regulation gives HOX-index change
-0.000376 (PDF: -0.027).
The 80% selective-block condition gives ALDH-fraction ratio
0.7471 (PDF: 0.7605) and HOX-index change
0.0182 (PDF: 0.0217).
These discrepancies are retained, with no parameter tuning to conceal them.

In particular, setting v5r=q13r=wBr=wCr=0 removes every RA input to the upstream
molecular/HOX-program subsystem in the printed equations. An ATRA-induced reduction
in beta-catenin cannot then explain a large negative HOX-index change; only the
population-composition weighting still changes that index. This is a useful point
to clarify with the report author. The ablation figure reports the implemented
equations, not the unmatched numerical claim.

Equation (6) as printed has no dB multiplier, although adjacent prose implies one. The primary
run follows the printed equation; this gives beta-catenin ratio 0.719095, consistent
with the PDF's 0.719. A separate physical-clock variant gives
0.717751. Population conclusions barely change.
Other molecular clocks use the exact stated half-lives; population rates are already per hour.

The four 6-h pulse endpoints are not listed explicitly in the PDF. This reproduction assumes
40–46, 54–60, 68–74, 82–88 h at twice nominal amplitude. The LHS seed is also not numerically
specified in the provided report, so the seed above is our explicit choice. Schedule and ensemble
details may consequently differ. Smooth pulse tails are integrated, with no artificial cutoff.

The PDF calls an ordinary Spearman correlation a PRCC-style analysis. Here the same statistic is
correctly labeled Spearman; no partial-correlation claim is made. Time 94.9 h is measured from
simulation baseline, not treatment start (40 h); it is approximately 54.9 h after treatment start.

The 720-h warm-up is followed exactly; it is not proof that the slower populations are at a
perfect periodic equilibrium. Their one-day residual changes are recorded in results.json.
No raw experimental data were supplied or fitted. The HOX index is a reduced model score,
not the eight-gene clinical signature, and these simulations do not predict patient survival.
The selective block is a hypothetical intervention on two model couplings, not an identified drug.

## Suggested 60-second explanation

“I implemented the complete 14-equation extension directly in SciPy and reproduced the main
48-hour response using the supplied parameters and preconditioning. Under severe APC loss,
the model gives about a 4.3% reduction in total cells, a 30.4% reduction in stem-like cells,
and a 21.0% reduction in the ALDH-like fraction. At the same time, its reduced HOX index
rises from 0.286 to 0.433. The stem-like population starts growing again about 6.9 hours
after washout while still roughly 31.5% below control. The dose-duration and mechanism
comparisons help explain this separation. These are preliminary reproduction results,
not a fit to experimental data or a clinical conclusion.”

## Files

- `meeting_brief.pdf`: presentation brief and four main plots.
- `all_figures.pdf`: all 14 figure pages; `figures/`: individual PNG and vector PDF plots.
- `index.html`: local browser gallery.
- `tables/regimes.csv`, `endpoints.csv`, `severe_timepoints.csv`: numerical results.
- `data/severe_APC_timeseries.csv`: every severe-regime state and observable, control and ATRA.
- `data/trajectories.npz`: all non-ensemble trajectories, named by scenario.
- `results.json`, `validation.json`, `parameters.json`, `config.json`, `manifest.json`:
  full settings, audits, numerical results and file/source hashes; `source/`: code snapshot.
