POPULATION EXTENSION — ALL FINAL PLOTS

PNG/                 14 high-resolution PNG figures
PDF/                 The same 14 figures as vector PDFs
All_Plots.pdf        All figures in one 14-page PDF
Meeting_Brief.pdf    Six-page presentation brief with the main plots

Figure numbers match the supplied report: 2–14 and 17.
Figure 1 is the report schematic; Figures 15–16 were not rerun.
Every unique numerical plot produced for the completed extension study is here.
Earlier diagnostic runs are retained on the server; duplicate versions are not
included in this final-figure collection.

Open PNG files to view or insert into slides. Use the vector PDFs for printing.
The main result is in fig04_central_result; recovery is in fig05_maintenance.

SciPy-only 14-state simulation, no neural networks or fitting. See the meeting
brief for scope and the source study's RESULTS.md for reproduction discrepancies.
Source run: 20260915_213018_population_extension_5128
